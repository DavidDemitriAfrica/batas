# Enrollment Data Module (School-level)

This module contains historical school-level enrollment data including:
- School identifiers and information
- Enrollment counts by gender, grade level, and track/strand (Senior High School)

from SY 2017-18 to SY 2024-25.

## Data Availability

| File | School Year |
|------|-------------|
| `enrollment_2017-18.csv` | 2017-18 |
| `enrollment_2018-19.csv` | 2018-19 |
| `enrollment_2019-20.csv` | 2019-20 |
| `enrollment_2020-21.csv` | 2020-21 |
| `enrollment_2021-22.csv` | 2021-22 |
| `enrollment_2022-23.csv` | 2022-23 |
| `enrollment_2023-24.csv` | 2023-24 |
| `enrollment_2024-25.csv` | 2024-25 |

## Variable Documentation

In this module, "SUC"/"LUC" means a school is managed by a "State University/College" or "Local University/College", respectively.

### School Information
| Variable Name | Data Type | Description | Notes |
|---------------|-----------|-------------|-------|
| `school_id` | integer | 6-digit unique school identifier | Links to other school datasets. As schools expand or shrink their curricular offerings, merge with other schools, etc., it is possible for school IDs to change between school years. This is a minority of cases. In future data releases, we intend to publish mapping data to assist with school ID tracking. |
| `school_name` | string | Official school name | |
| `region` | string | Administrative region name | As regions are renamed and/or have boundaries redrawn, it is possible for a school to change region between school years. |
| `division` | string | School division name | |
| `province` | string | Province name | |
| `school_district` | string | School district name | Variable only has values starting SY 2018-19. |
| `legislative_district` | string | Legislative district | |
| `municipality` | string | Municipality or city name | |
| `barangay` | string | Barangay name | |
| `street_address` | string | Street address | |
| `sector` | string | School sector | Takes one of the following values: Public, Private, SUC/LUC, or PSO (2018-19 onwards). |
| `school_management` | string | School management type | Takes one of the following values: Sectarian, Non-Sectarian, Local Government, DepEd Managed, DOST Managed, Other GA (Government Agency) Managed, LUC, SUC, Tahderriyah (2018-19 only), PSO (2018-19 onwards), International School (2019-20 onwards). |
| `annex_status` | string | School annex status | Variable only has values starting SY 2019-20. Takes one of the following values: Standalone School, Mother School, Annex/Extension School, Mobile School/Center. |
| `offers_es` | boolean | Offers Elementary School | |
| `offers_jhs` | boolean | Offers Junior High School | |
| `offers_shs` | boolean | Offers Senior High School | |

For Philippine Schools Overseas (PSOs):
- `region`, `province`, `municipality` equal 'PSO';
- `division` is the name of the overseas country;
- `school_district` is the name of the overseas city; and
- `legislative_district` equals 'PSO' or 'No Legislative District'.

### Elementary School Enrollment
| Variable Name | Data Type | Description | Notes |
|---------------|-----------|-------------|-------|
| `kinder_male` | nullable integer | Number of male Kindergarten students | |
| `kinder_female` | nullable integer | Number of female Kindergarten students | |
| `g1_male` | nullable integer | Number of male Grade 1 students | |
| `g1_female` | nullable integer | Number of female Grade 1 students | |
| `g2_male` | nullable integer | Number of male Grade 2 students | |
| `g2_female` | nullable integer | Number of female Grade 2 students | |
| `g3_male` | nullable integer | Number of male Grade 3 students | |
| `g3_female` | nullable integer | Number of female Grade 3 students | |
| `g4_male` | nullable integer | Number of male Grade 4 students | |
| `g4_female` | nullable integer | Number of female Grade 4 students | |
| `g5_male` | nullable integer | Number of male Grade 5 students | |
| `g5_female` | nullable integer | Number of female Grade 5 students | |
| `g6_male` | nullable integer | Number of male Grade 6 students | |
| `g6_female` | nullable integer | Number of female Grade 6 students | |
| `esng_male` | nullable integer | Number of male Elementary School non-graded students | |
| `esng_female` | nullable integer | Number of female Elementary School non-graded students | |

### Junior High School Enrollment
| Variable Name | Data Type | Description | Notes |
|---------------|-----------|-------------|-------|
| `g7_male` | nullable integer | Number of male Grade 7 students | |
| `g7_female` | nullable integer | Number of female Grade 7 students | |
| `g8_male` | nullable integer | Number of male Grade 8 students | |
| `g8_female` | nullable integer | Number of female Grade 8 students | |
| `g9_male` | nullable integer | Number of male Grade 9 students | |
| `g9_female` | nullable integer | Number of female Grade 9 students | |
| `g10_male` | nullable integer | Number of male Grade 10 students | |
| `g10_female` | nullable integer | Number of female Grade 10 students | |
| `jhsng_male` | nullable integer | Number of male Junior High School non-graded students | Missing data in SY 2018-19. |
| `jhsng_female` | nullable integer | Number of female Junior High School non-graded students | Missing data in SY 2018-19. |

### Senior High School Enrollment
| Variable Name | Data Type | Description | Notes |
|---------------|-----------|-------------|-------|
| `g11_abm_male` | nullable integer | Number of male Grade 11 ABM Strand students | Accountancy, Business and Management |
| `g11_abm_female` | nullable integer | Number of female Grade 11 ABM Strand students | Accountancy, Business and Management |
| `g11_arts_male` | nullable integer | Number of male Grade 11 Arts and Design Track students | |
| `g11_arts_female` | nullable integer | Number of female Grade 11 Arts and Design Track students | |
| `g11_gas_male` | nullable integer | Number of male Grade 11 GAS students | General Academic Strand |
| `g11_gas_female` | nullable integer | Number of female Grade 11 GAS students | General Academic Strand |
| `g11_humss_male` | nullable integer | Number of male Grade 11 HUMSS Strand students | Humanities and Social Sciences |
| `g11_humss_female` | nullable integer | Number of female Grade 11 HUMSS Strand students | Humanities and Social Sciences |
| `g11_maritime_male` | nullable integer | Number of male Grade 11 Pre-Baccalaureate Maritime Strand students | |
| `g11_maritime_female` | nullable integer | Number of female Grade 11 Pre-Baccalaureate Maritime Strand students | |
| `g11_sports_male` | nullable integer | Number of male Grade 11 Sports Track students | |
| `g11_sports_female` | nullable integer | Number of female Grade 11 Sports Track students | |
| `g11_stem_male` | nullable integer | Number of male Grade 11 STEM Strand students | Science, Technology, Engineering and Mathematics |
| `g11_stem_female` | nullable integer | Number of female Grade 11 STEM Strand students | Science, Technology, Engineering and Mathematics |
| `g11_tvl_male` | nullable integer | Number of male Grade 11 TVL Track students | Technical-Vocational-Livelihood |
| `g11_tvl_female` | nullable integer | Number of female Grade 11 TVL Track students | Technical-Vocational-Livelihood |
| `g11_unique_male` | nullable integer | Number of male Grade 11 students in other tracks unique to certain schools or localities | Variable only has values starting SY 2024-25. |
| `g11_unique_female` | nullable integer | Number of female Grade 11 students in other tracks unique to certain schools or localities | Variable only has values starting SY 2024-25. |

| `g12_abm_male` | nullable integer | Number of male Grade 12 ABM Strand students | Accountancy, Business and Management |
| `g12_abm_female` | nullable integer | Number of female Grade 12 ABM Strand students | Accountancy, Business and Management |
| `g12_arts_male` | nullable integer | Number of male Grade 12 Arts and Design Track students | |
| `g12_arts_female` | nullable integer | Number of female Grade 12 Arts and Design Track students | |
| `g12_gas_male` | nullable integer | Number of male Grade 12 GAS students | General Academic Strand |
| `g12_gas_female` | nullable integer | Number of female Grade 12 GAS students | General Academic Strand |
| `g12_humss_male` | nullable integer | Number of male Grade 12 HUMSS Strand students | Humanities and Social Sciences |
| `g12_humss_female` | nullable integer | Number of female Grade 12 HUMSS Strand students | Humanities and Social Sciences |
| `g12_maritime_male` | nullable integer | Number of male Grade 12 Pre-Baccalaureate Maritime Strand students | |
| `g12_maritime_female` | nullable integer | Number of female Grade 12 Pre-Baccalaureate Maritime Strand students | |
| `g12_sports_male` | nullable integer | Number of male Grade 12 Sports Track students | |
| `g12_sports_female` | nullable integer | Number of female Grade 12 Sports Track students | |
| `g12_stem_male` | nullable integer | Number of male Grade 12 STEM Strand students | Science, Technology, Engineering and Mathematics |
| `g12_stem_female` | nullable integer | Number of female Grade 12 STEM Strand students | Science, Technology, Engineering and Mathematics |
| `g12_tvl_male` | nullable integer | Number of male Grade 12 TVL Track students | Technical-Vocational-Livelihood |
| `g12_tvl_female` | nullable integer | Number of female Grade 12 TVL Track students | Technical-Vocational-Livelihood |
| `g12_unique_male` | nullable integer | Number of male Grade 12 students in other tracks unique to certain schools or localities | Variable only has values starting SY 2024-25. |
| `g12_unique_female` | nullable integer | Number of female Grade 12 students in other tracks unique to certain schools or localities | Variable only has values starting SY 2024-25. |

## Notes
Blank values mean the variable does not yet exist in that school year, or is missing in that school year.